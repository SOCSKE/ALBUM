<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            CountriesSeeder::class,
            UsersSeeder::class,
            DemoEventSeeder::class,
        ]);
    }
}

// ──────────────────────────────────────────────────────────────
// USUARIOS INICIALES
// ──────────────────────────────────────────────────────────────
class UsersSeeder extends Seeder
{
    public function run(): void
    {
        DB::table('users')->insert([
            [
                'id'       => Str::uuid(),
                'name'     => 'Super Admin',
                'email'    => 'admin@albumdigital2026.com',
                'password' => Hash::make('Admin2026!'),
                'role'     => 'superadmin',
                'is_active'=> 1,
                'email_verified_at' => now(),
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'id'       => Str::uuid(),
                'name'     => 'Organizador Demo',
                'email'    => 'organizador@demo.com',
                'password' => Hash::make('Demo2026!'),
                'role'     => 'organizer',
                'is_active'=> 1,
                'email_verified_at' => now(),
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);
    }
}

// ──────────────────────────────────────────────────────────────
// EVENTO DE DEMO (pre-activado para testing)
// ──────────────────────────────────────────────────────────────
class DemoEventSeeder extends Seeder
{
    public function run(): void
    {
        $tenantId = Str::uuid();
        $organizerId = DB::table('users')->where('email', 'organizador@demo.com')->value('id');

        // Crear tenant de demo
        DB::table('tenants')->insert([
            'id'              => $tenantId,
            'slug'            => 'DEMO2026',
            'name'            => 'Evento Demo - FIFA World Cup 2026',
            'description'     => 'Evento de demostración para testing de la plataforma',
            'organizer_email' => 'organizador@demo.com',
            'max_players'     => 50,
            'duration_hours'  => 48,
            'starts_at'       => now(),
            'ends_at'         => now()->addDays(2),
            'status'          => 'active',
            'primary_color'   => '#c60b1e',
            'created_at'      => now(),
            'updated_at'      => now(),
        ]);

        // Vincular organizador
        DB::table('tenant_organizers')->insert([
            'tenant_id'  => $tenantId,
            'user_id'    => $organizerId,
            'created_at' => now(),
        ]);

        // Crear 4 equipos de demo
        $teams = [
            ['ECU', 'Ecuador'],
            ['ARG', 'Argentina'],
            ['BRA', 'Brasil'],
            ['ESP', 'España'],
        ];

        $teamIds = [];
        foreach ($teams as [$code, $name]) {
            $countryId = DB::table('countries')->where('code', $code)->value('id');
            $teamId    = Str::uuid();
            DB::table('event_teams')->insert([
                'id'         => $teamId,
                'tenant_id'  => $tenantId,
                'country_id' => $countryId,
                'name'       => $name,
                'min_players'=> 5,
                'max_players'=> 15,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            $teamIds[$code] = $teamId;
        }

        // Crear jugadores de demo (20 jugadores, 5 por equipo)
        $teamCodes = array_keys($teamIds);
        for ($i = 1; $i <= 20; $i++) {
            $teamCode = $teamCodes[floor(($i - 1) / 5)];
            DB::table('players')->insert([
                'id'            => Str::uuid(),
                'tenant_id'     => $tenantId,
                'team_id'       => $teamIds[$teamCode],
                'first_name'    => "Jugador",
                'last_name'     => "Demo {$i}",
                'email'         => "jugador{$i}@demo.com",
                'phone'         => "099900{$i}001",
                'city'          => 'Guayaquil',
                'password'      => Hash::make('Demo2026!'),
                'selfie_url'    => "https://ui-avatars.com/api/?name=J+{$i}&background=random",
                'player_number' => $i,
                'album_progress'=> random_int(0, 80),
                'is_active'     => 1,
                'email_verified_at' => now(),
                'created_at'    => now(),
                'updated_at'    => now(),
            ]);
        }

        $this->command->info("✓ Evento DEMO2026 creado con 20 jugadores");
        $this->command->info("  URL: /game/DEMO2026");
        $this->command->info("  Login jugador: jugador1@demo.com / Demo2026!");
    }
}
