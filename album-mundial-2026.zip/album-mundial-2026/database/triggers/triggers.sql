-- ============================================================
-- TRIGGERS MySQL 8 - Álbum Digital FIFA World Cup 2026
-- ============================================================

DELIMITER $$

-- ============================================================
-- TRIGGER: Calcular progreso del álbum al insertar un cromo
-- ============================================================
CREATE TRIGGER `trg_update_album_progress`
AFTER INSERT ON `album_cards`
FOR EACH ROW
BEGIN
  DECLARE total_players INT;
  DECLARE cards_count INT;
  DECLARE new_progress TINYINT;

  -- Total de jugadores en el evento
  SELECT COUNT(*) INTO total_players
  FROM players
  WHERE tenant_id = NEW.tenant_id AND is_active = 1;

  -- Cromos válidos del jugador
  SELECT COUNT(*) INTO cards_count
  FROM album_cards
  WHERE owner_id = NEW.owner_id
    AND face_match_status = 'approved'
    AND tenant_id = NEW.tenant_id;

  -- Calcular porcentaje
  IF total_players > 0 THEN
    SET new_progress = LEAST(100, FLOOR((cards_count / total_players) * 100));
  ELSE
    SET new_progress = 0;
  END IF;

  -- Actualizar progreso del jugador
  UPDATE players
  SET album_progress = new_progress,
      updated_at = NOW()
  WHERE id = NEW.owner_id;
END$$

-- ============================================================
-- TRIGGER: Verificar estado del equipo al asignar jugador
-- ============================================================
CREATE TRIGGER `trg_check_team_complete`
AFTER UPDATE ON `players`
FOR EACH ROW
BEGIN
  DECLARE team_count INT;
  DECLARE min_req TINYINT;

  IF NEW.team_id IS NOT NULL AND (OLD.team_id != NEW.team_id OR OLD.team_id IS NULL) THEN
    SELECT COUNT(*), MIN(min_players) INTO team_count, min_req
    FROM players p
    JOIN event_teams et ON et.id = p.team_id
    WHERE p.team_id = NEW.team_id AND p.is_active = 1 AND p.tenant_id = NEW.tenant_id
    GROUP BY et.id, et.min_players;

    IF team_count >= min_req THEN
      UPDATE event_teams
      SET status = 'complete', updated_at = NOW()
      WHERE id = NEW.team_id;
    END IF;
  END IF;
END$$

-- ============================================================
-- TRIGGER: Auto-asignar número de jugador al registrarse
-- ============================================================
CREATE TRIGGER `trg_assign_player_number`
BEFORE INSERT ON `players`
FOR EACH ROW
BEGIN
  DECLARE next_num SMALLINT;

  SELECT COALESCE(MAX(player_number), 0) + 1 INTO next_num
  FROM players
  WHERE tenant_id = NEW.tenant_id;

  SET NEW.player_number = next_num;
END$$

-- ============================================================
-- TRIGGER: Log de auditoría en pagos
-- ============================================================
CREATE TRIGGER `trg_audit_payment_status`
AFTER UPDATE ON `payments`
FOR EACH ROW
BEGIN
  IF OLD.status != NEW.status THEN
    INSERT INTO audit_logs (id, tenant_id, user_type, user_id, action, model, model_id, old_values, new_values, created_at)
    VALUES (
      UUID(),
      NEW.tenant_id,
      'User',
      NEW.user_id,
      'payment_status_changed',
      'Payment',
      NEW.id,
      JSON_OBJECT('status', OLD.status),
      JSON_OBJECT('status', NEW.status),
      NOW()
    );

    -- Si el pago se completó, activar el evento
    IF NEW.status = 'completed' THEN
      UPDATE tenants
      SET status = 'active', updated_at = NOW()
      WHERE id = NEW.tenant_id AND status = 'pending';
    END IF;
  END IF;
END$$

-- ============================================================
-- TRIGGER: Verificar límite de jugadores por evento
-- ============================================================
CREATE TRIGGER `trg_check_player_limit`
BEFORE INSERT ON `players`
FOR EACH ROW
BEGIN
  DECLARE current_count SMALLINT;
  DECLARE max_allowed SMALLINT;

  SELECT COUNT(*) INTO current_count
  FROM players
  WHERE tenant_id = NEW.tenant_id AND is_active = 1;

  SELECT max_players INTO max_allowed
  FROM tenants
  WHERE id = NEW.tenant_id;

  IF current_count >= max_allowed THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'El evento ha alcanzado el límite máximo de jugadores';
  END IF;
END$$

-- ============================================================
-- TRIGGER: Validar que el álbum de cromo sea único por dueño
-- ============================================================
CREATE TRIGGER `trg_prevent_duplicate_card`
BEFORE INSERT ON `album_cards`
FOR EACH ROW
BEGIN
  DECLARE card_exists INT;

  SELECT COUNT(*) INTO card_exists
  FROM album_cards
  WHERE owner_id = NEW.owner_id
    AND subject_id = NEW.subject_id
    AND tenant_id = NEW.tenant_id
    AND face_match_status != 'rejected';

  IF card_exists > 0 THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Ya existe un cromo de este jugador en tu álbum';
  END IF;
END$$

DELIMITER ;
