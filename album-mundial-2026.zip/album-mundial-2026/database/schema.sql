-- ============================================================
-- ÁLBUM DIGITAL FIFA WORLD CUP 2026
-- Script MySQL 8 - Schema Completo
-- ============================================================

SET FOREIGN_KEY_CHECKS = 0;
SET NAMES utf8mb4;

-- ============================================================
-- TABLA: tenants (eventos = tenants)
-- ============================================================
CREATE TABLE IF NOT EXISTS `tenants` (
  `id`                  CHAR(36)      NOT NULL,
  `slug`                VARCHAR(20)   NOT NULL UNIQUE COMMENT 'Código único del evento: ABC123XYZ',
  `name`                VARCHAR(150)  NOT NULL,
  `description`         TEXT,
  `organizer_email`     VARCHAR(150)  NOT NULL,
  `organizer_phone`     VARCHAR(30),
  `logo_url`            VARCHAR(500),
  `primary_color`       VARCHAR(7)    DEFAULT '#1a56db',
  `max_players`         SMALLINT      NOT NULL DEFAULT 25,
  `duration_hours`      SMALLINT      NOT NULL DEFAULT 24,
  `starts_at`           DATETIME      NOT NULL,
  `ends_at`             DATETIME      NOT NULL,
  `status`              ENUM('pending','active','suspended','finished') NOT NULL DEFAULT 'pending',
  `settings`            JSON          COMMENT 'Configuraciones extras del evento',
  `created_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_tenants_slug` (`slug`),
  INDEX `idx_tenants_status` (`status`),
  INDEX `idx_tenants_starts_at` (`starts_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLA: users (superadmin + organizadores)
-- ============================================================
CREATE TABLE IF NOT EXISTS `users` (
  `id`                  CHAR(36)      NOT NULL,
  `name`                VARCHAR(150)  NOT NULL,
  `email`               VARCHAR(150)  NOT NULL UNIQUE,
  `email_verified_at`   DATETIME,
  `password`            VARCHAR(255)  NOT NULL COMMENT 'bcrypt hash',
  `role`                ENUM('superadmin','organizer') NOT NULL DEFAULT 'organizer',
  `phone`               VARCHAR(30),
  `two_factor_secret`   VARCHAR(255),
  `two_factor_enabled`  TINYINT(1)    NOT NULL DEFAULT 0,
  `last_login_at`       DATETIME,
  `last_login_ip`       VARCHAR(45),
  `is_active`           TINYINT(1)    NOT NULL DEFAULT 1,
  `remember_token`      VARCHAR(100),
  `created_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_users_email` (`email`),
  INDEX `idx_users_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLA: tenant_organizers (relación evento ↔ organizador)
-- ============================================================
CREATE TABLE IF NOT EXISTS `tenant_organizers` (
  `tenant_id`           CHAR(36)      NOT NULL,
  `user_id`             CHAR(36)      NOT NULL,
  `created_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`tenant_id`, `user_id`),
  CONSTRAINT `fk_to_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_to_user`   FOREIGN KEY (`user_id`)   REFERENCES `users`(`id`)   ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLA: countries (países participantes del mundial)
-- ============================================================
CREATE TABLE IF NOT EXISTS `countries` (
  `id`                  SMALLINT      NOT NULL AUTO_INCREMENT,
  `name`                VARCHAR(100)  NOT NULL,
  `code`                CHAR(3)       NOT NULL UNIQUE COMMENT 'FIFA code: ARG, BRA, ECU',
  `flag_url`            VARCHAR(500),
  `shield_url`          VARCHAR(500),
  `primary_color`       VARCHAR(7)    NOT NULL DEFAULT '#000000',
  `secondary_color`     VARCHAR(7)    NOT NULL DEFAULT '#FFFFFF',
  `confederation`       ENUM('UEFA','CONMEBOL','CONCACAF','CAF','AFC','OFC') NOT NULL,
  `is_active`           TINYINT(1)    NOT NULL DEFAULT 1,
  `created_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_countries_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLA: event_teams (equipos asignados a un evento)
-- ============================================================
CREATE TABLE IF NOT EXISTS `event_teams` (
  `id`                  CHAR(36)      NOT NULL,
  `tenant_id`           CHAR(36)      NOT NULL,
  `country_id`          SMALLINT      NOT NULL,
  `name`                VARCHAR(100)  NOT NULL,
  `min_players`         TINYINT       NOT NULL DEFAULT 5,
  `max_players`         TINYINT       NOT NULL DEFAULT 25,
  `status`              ENUM('incomplete','complete') NOT NULL DEFAULT 'incomplete',
  `created_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_team_per_event` (`tenant_id`, `country_id`),
  CONSTRAINT `fk_et_tenant`  FOREIGN KEY (`tenant_id`)  REFERENCES `tenants`(`id`)   ON DELETE CASCADE,
  CONSTRAINT `fk_et_country` FOREIGN KEY (`country_id`) REFERENCES `countries`(`id`) ON DELETE RESTRICT,
  INDEX `idx_et_tenant` (`tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLA: players (jugadores por evento)
-- ============================================================
CREATE TABLE IF NOT EXISTS `players` (
  `id`                  CHAR(36)      NOT NULL,
  `tenant_id`           CHAR(36)      NOT NULL,
  `team_id`             CHAR(36),
  `first_name`          VARCHAR(80)   NOT NULL,
  `last_name`           VARCHAR(80)   NOT NULL,
  `email`               VARCHAR(150)  NOT NULL,
  `phone`               VARCHAR(30)   NOT NULL,
  `city`                VARCHAR(100),
  `password`            VARCHAR(255)  NOT NULL,
  `selfie_url`          VARCHAR(500)  NOT NULL COMMENT 'Selfie original de registro',
  `selfie_embedding`    JSON          COMMENT 'Vector facial para comparación',
  `player_number`       SMALLINT      NOT NULL COMMENT 'Número en el álbum',
  `qr_code`             VARCHAR(255)  COMMENT 'Código QR único',
  `card_url_png`        VARCHAR(500)  COMMENT 'Cromo generado PNG',
  `card_url_webp`       VARCHAR(500)  COMMENT 'Cromo generado WEBP',
  `album_progress`      TINYINT       NOT NULL DEFAULT 0 COMMENT 'Porcentaje completado 0-100',
  `last_login_at`       DATETIME,
  `last_login_ip`       VARCHAR(45),
  `device_fingerprint`  VARCHAR(255),
  `is_active`           TINYINT(1)    NOT NULL DEFAULT 1,
  `email_verified_at`   DATETIME,
  `created_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_player_email`  (`tenant_id`, `email`),
  UNIQUE KEY `uq_player_phone`  (`tenant_id`, `phone`),
  UNIQUE KEY `uq_player_number` (`tenant_id`, `player_number`),
  CONSTRAINT `fk_p_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants`(`id`)     ON DELETE CASCADE,
  CONSTRAINT `fk_p_team`   FOREIGN KEY (`team_id`)   REFERENCES `event_teams`(`id`) ON DELETE SET NULL,
  INDEX `idx_players_tenant`   (`tenant_id`),
  INDEX `idx_players_team`     (`team_id`),
  INDEX `idx_players_progress` (`album_progress`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLA: album_cards (cromos del álbum)
-- ============================================================
CREATE TABLE IF NOT EXISTS `album_cards` (
  `id`                  CHAR(36)      NOT NULL,
  `tenant_id`           CHAR(36)      NOT NULL,
  `owner_id`            CHAR(36)      NOT NULL COMMENT 'Jugador dueño del cromo',
  `subject_id`          CHAR(36)      NOT NULL COMMENT 'Jugador fotografiado',
  `photo_url`           VARCHAR(500)  NOT NULL COMMENT 'Foto tomada para generar cromo',
  `card_url_png`        VARCHAR(500),
  `card_url_webp`       VARCHAR(500),
  `face_match_score`    DECIMAL(5,2)  NOT NULL COMMENT 'Score IA reconocimiento facial 0-100',
  `face_match_status`   ENUM('approved','pending_review','rejected') NOT NULL DEFAULT 'approved',
  `fraud_flags`         JSON          COMMENT 'Flags de fraude detectados',
  `ip_address`          VARCHAR(45)   NOT NULL,
  `device_info`         JSON,
  `captured_at`         DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `reviewed_at`         DATETIME,
  `reviewed_by`         CHAR(36)      COMMENT 'Admin que revisó',
  `created_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_card_unique`   (`tenant_id`, `owner_id`, `subject_id`),
  CONSTRAINT `fk_ac_tenant`    FOREIGN KEY (`tenant_id`)  REFERENCES `tenants`(`id`)  ON DELETE CASCADE,
  CONSTRAINT `fk_ac_owner`     FOREIGN KEY (`owner_id`)   REFERENCES `players`(`id`)  ON DELETE CASCADE,
  CONSTRAINT `fk_ac_subject`   FOREIGN KEY (`subject_id`) REFERENCES `players`(`id`)  ON DELETE CASCADE,
  INDEX `idx_ac_owner`         (`owner_id`),
  INDEX `idx_ac_tenant`        (`tenant_id`),
  INDEX `idx_ac_face_status`   (`face_match_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLA: card_trades (intercambio de cromos)
-- ============================================================
CREATE TABLE IF NOT EXISTS `card_trades` (
  `id`                  CHAR(36)      NOT NULL,
  `tenant_id`           CHAR(36)      NOT NULL,
  `from_player_id`      CHAR(36)      NOT NULL,
  `to_player_id`        CHAR(36)      NOT NULL,
  `card_id`             CHAR(36)      NOT NULL,
  `status`              ENUM('pending','accepted','rejected','cancelled') NOT NULL DEFAULT 'pending',
  `message`             VARCHAR(300),
  `created_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_ct_tenant` FOREIGN KEY (`tenant_id`)     REFERENCES `tenants`(`id`)  ON DELETE CASCADE,
  CONSTRAINT `fk_ct_from`   FOREIGN KEY (`from_player_id`) REFERENCES `players`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ct_to`     FOREIGN KEY (`to_player_id`)   REFERENCES `players`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ct_card`   FOREIGN KEY (`card_id`)        REFERENCES `album_cards`(`id`) ON DELETE CASCADE,
  INDEX `idx_ct_tenant` (`tenant_id`),
  INDEX `idx_ct_from`   (`from_player_id`),
  INDEX `idx_ct_to`     (`to_player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLA: payments (pagos de eventos)
-- ============================================================
CREATE TABLE IF NOT EXISTS `payments` (
  `id`                  CHAR(36)      NOT NULL,
  `tenant_id`           CHAR(36)      NOT NULL,
  `user_id`             CHAR(36)      NOT NULL,
  `gateway`             ENUM('kushki','payphone','paypal','stripe') NOT NULL,
  `gateway_tx_id`       VARCHAR(255)  COMMENT 'ID de transacción en la pasarela',
  `amount_usd`          DECIMAL(10,2) NOT NULL,
  `player_blocks`       TINYINT       NOT NULL COMMENT 'Bloques de 25 jugadores',
  `max_players`         SMALLINT      NOT NULL,
  `status`              ENUM('pending','completed','failed','refunded') NOT NULL DEFAULT 'pending',
  `webhook_payload`     JSON          COMMENT 'Payload recibido del webhook',
  `invoice_number`      VARCHAR(50)   COMMENT 'Para facturación futura',
  `paid_at`             DATETIME,
  `created_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_pay_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants`(`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_pay_user`   FOREIGN KEY (`user_id`)   REFERENCES `users`(`id`)   ON DELETE RESTRICT,
  INDEX `idx_pay_tenant`    (`tenant_id`),
  INDEX `idx_pay_status`    (`status`),
  INDEX `idx_pay_gateway`   (`gateway`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLA: rankings_cache (cache de rankings por evento)
-- ============================================================
CREATE TABLE IF NOT EXISTS `rankings_cache` (
  `id`                  CHAR(36)      NOT NULL,
  `tenant_id`           CHAR(36)      NOT NULL,
  `type`                ENUM('individual','team','speed','album_complete','general') NOT NULL,
  `rank`                SMALLINT      NOT NULL,
  `reference_id`        CHAR(36)      NOT NULL COMMENT 'ID de jugador o equipo',
  `reference_name`      VARCHAR(200)  NOT NULL,
  `score`               DECIMAL(10,2) NOT NULL DEFAULT 0,
  `extra_data`          JSON,
  `computed_at`         DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_rank_tenant_type` (`tenant_id`, `type`),
  INDEX `idx_rank_computed_at` (`computed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLA: notifications (notificaciones)
-- ============================================================
CREATE TABLE IF NOT EXISTS `notifications` (
  `id`                  CHAR(36)      NOT NULL,
  `tenant_id`           CHAR(36),
  `notifiable_type`     VARCHAR(100)  NOT NULL COMMENT 'players o users',
  `notifiable_id`       CHAR(36)      NOT NULL,
  `type`                VARCHAR(100)  NOT NULL COMMENT 'welcome, card_unlocked, album_complete...',
  `channel`             ENUM('email','push','whatsapp') NOT NULL DEFAULT 'email',
  `data`                JSON          NOT NULL,
  `read_at`             DATETIME,
  `sent_at`             DATETIME,
  `created_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_notif_notifiable` (`notifiable_type`, `notifiable_id`),
  INDEX `idx_notif_tenant`     (`tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLA: audit_logs (auditoría de seguridad)
-- ============================================================
CREATE TABLE IF NOT EXISTS `audit_logs` (
  `id`                  BIGINT        NOT NULL AUTO_INCREMENT,
  `tenant_id`           CHAR(36),
  `user_type`           VARCHAR(50)   COMMENT 'User o Player',
  `user_id`             CHAR(36),
  `action`              VARCHAR(100)  NOT NULL,
  `model`               VARCHAR(100),
  `model_id`            VARCHAR(36),
  `old_values`          JSON,
  `new_values`          JSON,
  `ip_address`          VARCHAR(45),
  `user_agent`          VARCHAR(500),
  `created_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_audit_user`      (`user_id`),
  INDEX `idx_audit_tenant`    (`tenant_id`),
  INDEX `idx_audit_action`    (`action`),
  INDEX `idx_audit_created`   (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLA: photo_fraud_log (log de intentos de fraude)
-- ============================================================
CREATE TABLE IF NOT EXISTS `photo_fraud_log` (
  `id`                  BIGINT        NOT NULL AUTO_INCREMENT,
  `tenant_id`           CHAR(36)      NOT NULL,
  `player_id`           CHAR(36)      NOT NULL,
  `fraud_type`          ENUM('duplicate','old_photo','manipulated','no_face_match','other') NOT NULL,
  `photo_hash`          VARCHAR(64)   COMMENT 'perceptual hash de la foto',
  `face_score`          DECIMAL(5,2),
  `ip_address`          VARCHAR(45),
  `device_info`         JSON,
  `created_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_fraud_player` (`player_id`),
  INDEX `idx_fraud_type`   (`fraud_type`),
  INDEX `idx_fraud_hash`   (`photo_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLA: payment_gateways_config (configuración de pasarelas)
-- ============================================================
CREATE TABLE IF NOT EXISTS `payment_gateways_config` (
  `id`                  TINYINT       NOT NULL AUTO_INCREMENT,
  `gateway`             ENUM('kushki','payphone','paypal','stripe') NOT NULL UNIQUE,
  `is_active`           TINYINT(1)    NOT NULL DEFAULT 0,
  `config`              JSON          NOT NULL COMMENT 'Credenciales cifradas',
  `sandbox_mode`        TINYINT(1)    NOT NULL DEFAULT 1,
  `created_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLA: system_settings (configuraciones globales)
-- ============================================================
CREATE TABLE IF NOT EXISTS `system_settings` (
  `key`                 VARCHAR(100)  NOT NULL,
  `value`               TEXT,
  `type`                ENUM('string','integer','boolean','json') NOT NULL DEFAULT 'string',
  `description`         VARCHAR(300),
  `updated_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
-- DATOS INICIALES
-- ============================================================

-- Configuraciones del sistema
INSERT INTO `system_settings` (`key`, `value`, `type`, `description`) VALUES
('price_per_block',       '5.00',   'string',  'Precio en USD por bloque de 25 jugadores'),
('players_per_block',     '25',     'integer', 'Jugadores por bloque'),
('max_players_per_event', '500',    'integer', 'Máximo de jugadores por evento'),
('default_event_hours',   '24',     'integer', 'Duración por defecto del evento en horas'),
('min_team_players',      '5',      'integer', 'Mínimo de jugadores por equipo'),
('face_match_threshold',  '80.00',  'string',  'Porcentaje mínimo de coincidencia facial'),
('active_gateway',        'stripe', 'string',  'Pasarela de pago activa');

-- Países del Mundial 2026
INSERT INTO `countries` (`name`, `code`, `primary_color`, `secondary_color`, `confederation`, `is_active`) VALUES
('Argentina',      'ARG', '#75aadb', '#ffffff', 'CONMEBOL', 1),
('Brasil',         'BRA', '#009c3b', '#ffdf00', 'CONMEBOL', 1),
('Ecuador',        'ECU', '#ffdd00', '#003580', 'CONMEBOL', 1),
('Uruguay',        'URY', '#74acdf', '#ffffff', 'CONMEBOL', 1),
('Colombia',       'COL', '#fcd116', '#003087', 'CONMEBOL', 1),
('Chile',          'CHL', '#d52b1e', '#ffffff', 'CONMEBOL', 1),
('Venezuela',      'VEN', '#cf142b', '#003087', 'CONMEBOL', 1),
('Bolivia',        'BOL', '#d52b1e', '#f9d000', 'CONMEBOL', 1),
('Paraguay',       'PRY', '#d52b1e', '#ffffff', 'CONMEBOL', 1),
('Perú',           'PER', '#d91023', '#ffffff', 'CONMEBOL', 1),
('España',         'ESP', '#c60b1e', '#ffc400', 'UEFA',     1),
('Francia',        'FRA', '#0055a4', '#ef4135', 'UEFA',     1),
('Alemania',       'GER', '#000000', '#dd0000', 'UEFA',     1),
('Inglaterra',     'ENG', '#cf091f', '#ffffff', 'UEFA',     1),
('Portugal',       'POR', '#006600', '#ff0000', 'UEFA',     1),
('Italia',         'ITA', '#0066cc', '#ffffff', 'UEFA',     1),
('Países Bajos',   'NED', '#ff6400', '#001489', 'UEFA',     1),
('Bélgica',        'BEL', '#000000', '#f50100', 'UEFA',     1),
('Croacia',        'CRO', '#ff0000', '#ffffff', 'UEFA',     1),
('Suiza',          'SUI', '#ff0000', '#ffffff', 'UEFA',     1),
('México',         'MEX', '#006847', '#ce1126', 'CONCACAF', 1),
('Estados Unidos', 'USA', '#3c3b6e', '#b22234', 'CONCACAF', 1),
('Canadá',         'CAN', '#ff0000', '#ffffff', 'CONCACAF', 1),
('Marruecos',      'MAR', '#c1272d', '#006233', 'CAF',      1),
('Senegal',        'SEN', '#00853f', '#fdef42', 'CAF',      1),
('Nigeria',        'NGA', '#008751', '#ffffff', 'CAF',      1),
('Camerún',        'CMR', '#007a5e', '#ce1126', 'CAF',      1),
('Japón',          'JPN', '#bc002d', '#ffffff', 'AFC',      1),
('Arabia Saudita', 'KSA', '#006c35', '#ffffff', 'AFC',      1),
('Australia',      'AUS', '#ffcd00', '#00843d', 'AFC',      1),
('Corea del Sur',  'KOR', '#cd2e3a', '#003478', 'AFC',      1),
('Qatar',          'QAT', '#8d1b3d', '#ffffff', 'AFC',      1);

-- Pasarelas de pago (modo sandbox)
INSERT INTO `payment_gateways_config` (`gateway`, `is_active`, `config`, `sandbox_mode`) VALUES
('stripe',   1, '{"public_key":"pk_test_xxx","secret_key":"sk_test_xxx","webhook_secret":"whsec_xxx"}', 1),
('paypal',   0, '{"client_id":"","client_secret":"","mode":"sandbox"}', 1),
('kushki',   0, '{"public_merchant_id":"","private_merchant_id":"","region":"Ecuador"}', 1),
('payphone', 0, '{"token":"","store_id":""}', 1);
