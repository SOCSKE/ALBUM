# 🏆 ÁLBUM DIGITAL FIFA WORLD CUP 2026

Plataforma SaaS para la creación y gestión de álbumes digitales mundialistas.

## Stack Tecnológico

| Capa | Tecnología |
|---|---|
| Frontend | Next.js 15, React 19, TypeScript, TailwindCSS, PWA |
| Backend | Laravel 12, PHP 8.4 |
| Base de datos | MySQL 8 |
| Cache / Colas | Redis |
| Almacenamiento | Cloudflare R2 |
| CDN | Cloudflare |
| Auth | JWT |
| Frontend Deploy | Vercel |
| Backend Deploy | Railway |

## Estructura del Proyecto

```
album-mundial-2026/
├── README.md
├── docker/
│   ├── Dockerfile.backend
│   ├── Dockerfile.frontend
│   └── docker-compose.yml
├── scripts/
│   ├── deploy.sh
│   ├── setup.sh
│   └── seed.sh
├── docs/
│   ├── functional/  → Documento funcional completo
│   ├── technical/   → Documento técnico
│   ├── uml/         → Diagramas UML
│   └── api/         → OpenAPI / Swagger
├── database/
│   ├── schema.sql          → Script MySQL completo
│   ├── migrations/         → Migraciones Laravel
│   ├── seeders/            → Seeders
│   ├── factories/          → Factories
│   └── triggers/           → Triggers MySQL
├── backend/                → Laravel 12
│   ├── app/
│   │   ├── Http/
│   │   │   ├── Controllers/
│   │   │   ├── Middleware/
│   │   │   ├── Requests/
│   │   │   └── Resources/
│   │   ├── Models/
│   │   ├── Services/
│   │   ├── Jobs/
│   │   ├── Events/
│   │   └── Repositories/
│   ├── config/
│   ├── routes/
│   └── tests/
├── frontend/               → Next.js 15
│   └── src/
│       ├── app/
│       ├── components/
│       ├── lib/
│       ├── hooks/
│       ├── types/
│       └── store/
└── tests/
    ├── unit/
    ├── integration/
    └── e2e/
```

## Modelo de Negocio

- **USD $5** por cada bloque de 25 jugadores
- Máximo: 500 jugadores por evento
- Duración por defecto: 24 horas (configurable)
- Multi-tenant: 1 tenant = 1 evento

## Inicio Rápido

```bash
# Clonar repositorio
git clone https://github.com/tu-org/album-mundial-2026

# Levantar con Docker
cd album-mundial-2026
docker-compose up -d

# Backend: instalar dependencias
cd backend && composer install
cp .env.example .env
php artisan key:generate
php artisan migrate --seed

# Frontend: instalar dependencias
cd frontend && npm install
cp .env.local.example .env.local
npm run dev
```

## Documentación

- [Documento Funcional](./docs/functional/README.md)
- [Documento Técnico](./docs/technical/README.md)
- [API Reference](./docs/api/openapi.yaml)
- [Guía de Despliegue](./scripts/README.md)
