# Documento Técnico — Álbum Digital FIFA World Cup 2026

## 1. Arquitectura General

### Patrón Arquitectónico: Multi-Tenant SaaS

El sistema implementa **Tenant por Evento**: cada evento creado es un tenant completamente aislado. El aislamiento es lógico (columna `tenant_id` en todas las tablas), con validación a nivel de aplicación y base de datos via triggers.

```
┌──────────────────────────────────────────────────────────────┐
│                     INTERNET / CDN (Cloudflare)              │
└────────────────────┬─────────────────────────────────────────┘
                     │
          ┌──────────┴──────────┐
          │                     │
   ┌──────▼──────┐       ┌──────▼──────┐
   │  VERCEL     │       │  RAILWAY    │
   │  Next.js 15 │       │ Laravel 12  │
   │  (Frontend) │       │ (Backend)   │
   └──────┬──────┘       └──────┬──────┘
          │                     │
          │ HTTPS REST API       │
          └──────────┬───────────┘
                     │
          ┌──────────┼──────────┐
          │          │          │
   ┌──────▼──┐  ┌────▼────┐  ┌─▼──────────┐
   │ MySQL 8 │  │ Redis 7 │  │ Cloudflare │
   │(Railway)│  │(Railway)│  │     R2     │
   └─────────┘  └─────────┘  └────────────┘
```

### Flujo de Autenticación

```
JWT (HS256)
├── Organizadores/Admin → TTL: 24h → Guard: api
└── Jugadores          → TTL: 8h  → Guard: players
    └── Scope limitado al tenant del evento
```

## 2. Modelo de Datos

### Entidades principales

| Entidad           | Descripción                                    |
|---|---|
| `tenants`         | Evento = Tenant. Un registro por evento        |
| `users`           | Superadmin + Organizadores (acceso global)     |
| `players`         | Jugadores (scoped por tenant_id)               |
| `event_teams`     | Equipos/selecciones de cada evento             |
| `countries`       | Catálogo global de países del Mundial          |
| `album_cards`     | Cromos generados (owner_id × subject_id)       |
| `card_trades`     | Intercambios de cromos entre jugadores         |
| `payments`        | Pagos de activación de eventos                 |
| `rankings_cache`  | Cache de rankings (se recalcula via Job)       |
| `audit_logs`      | Auditoría de seguridad OWASP                   |
| `photo_fraud_log` | Intentos de fraude detectados                  |

### Relaciones clave

```
Tenant ──1:N──► Players
Tenant ──1:N──► EventTeams
EventTeams ──N:1──► Countries
Player ──N:1──► EventTeam
Player ──1:N──► AlbumCards (como owner)
Player ──1:N──► AlbumCards (como subject)
AlbumCard: UNIQUE (tenant_id, owner_id, subject_id)
```

## 3. Módulo de Reconocimiento Facial

### Flujo de validación

```
[Jugador sube foto]
       │
       ▼
[1. Anti-fraude: hash perceptual + EXIF + duplicados]
       │
       ├── BLOQUEADO ──► Log de fraude + rechazo inmediato
       │
       ▼
[2. Face Match: foto vs selfie del sujeto]
       │
       ├── Score ≥ 80% ──► status: approved ──► GenerateCardJob::dispatch()
       │
       └── Score < 80% ──► status: pending_review ──► Cola de revisión manual
```

### Drivers soportados (intercambiables via config)

| Driver | Servicio | Precision |
|---|---|---|
| `aws_rekognition` | AWS Rekognition CompareFaces | Alta |
| `azure_face`      | Azure Cognitive Services Face API | Alta |
| `mock`            | Siempre retorna 90% (para tests) | N/A |

## 4. Generación de Cromos (GenerateCardJob)

El proceso es completamente asíncrono via Redis Queue:

1. `CardService::capture()` crea el registro y dispara el Job
2. `GenerateCardJob::handle()`:
   - Descarga foto del jugador desde R2
   - Crea canvas 460×620px con Intervention Image
   - Aplica: fondo con colores del país, foto, número, nombre, escudo, QR
   - Genera PNG y WEBP
   - Sube a Cloudflare R2
   - Actualiza `album_cards.card_url_png/webp`
3. Trigger MySQL actualiza `players.album_progress` automáticamente

## 5. Pasarelas de Pago

### Diseño desacoplado (Strategy Pattern)

```php
interface PaymentGatewayInterface {
    createCheckout(array $params): array
    verifyWebhook(array $payload): bool
    extractTransactionId(array $payload): string
    queryTransaction(string $txId): array
}
```

Implementaciones: `StripeGateway`, `PaypalGateway`, `KushkiGateway`, `PayphoneGateway`

La pasarela activa se configura en `payment_gateways_config.is_active`.

### Flujo de activación automática

```
[Webhook recibido]
       │
       ▼
[Verificar firma del gateway]
       │
       ▼
[Actualizar Payment.status = 'completed']
       │
       ▼
[TRIGGER MySQL: UPDATE tenants SET status = 'active']
       │
       ▼
[Evento listo para recibir jugadores]
```

## 6. Seguridad (OWASP Top 10)

| Amenaza | Mitigación implementada |
|---|---|
| A01 Broken Access Control | Multi-tenant scope en todas las queries; role guards |
| A02 Cryptographic Failures | bcrypt para passwords; JWT HS256; HTTPS obligatorio |
| A03 Injection | Eloquent ORM (prepared statements); sanitización inputs |
| A04 Insecure Design | Validación de límites vía trigger MySQL + application layer |
| A05 Security Misconfiguration | .env separado por entorno; headers de seguridad via Nginx |
| A06 Vulnerable Components | Dependabot + npm audit en CI/CD |
| A07 Auth Failures | Rate limiting en login (5 intentos/min); JWT TTL corto |
| A08 Software Integrity | Firma de webhooks verificada en cada gateway |
| A09 Logging & Monitoring | audit_logs + photo_fraud_log; alertas en Railway |
| A10 SSRF | Validación de URLs en uploads; lista blanca de dominios |

Adicionalmente:
- CSRF: deshabilitado para API stateless; verificado en webhooks por firma
- Rate Limiting: 60 req/min global, 5 req/min en auth via Redis
- 2FA opcional para organizadores y superadmin

## 7. Stack de Colas (Redis)

```
Queue: album_jobs
├── GenerateCardJob      → genera imagen del cromo (prioridad alta)
├── SendNotificationJob  → email/push/WhatsApp
├── ComputeRankingJob    → recalcular rankings cada 5 min
└── CleanupExpiredJob    → limpiar eventos finalizados (diario)
```

## 8. PWA (Progressive Web App)

El frontend Next.js 15 incluye:
- `manifest.json` con íconos, tema y display: standalone
- Service Worker para cache offline de assets estáticos
- Push Notifications via FCM
- Instalable en iOS y Android desde el navegador

## 9. Infraestructura de Producción

| Componente | Servicio | Especificaciones |
|---|---|---|
| Frontend | Vercel | Auto-scale; Edge Network global |
| Backend API | Railway | 1 vCPU / 512MB mínimo |
| Queue Worker | Railway (servicio separado) | 1 worker permanente |
| MySQL | Railway | MySQL 8.3 managed |
| Redis | Railway | Redis 7.2 managed |
| Almacenamiento | Cloudflare R2 | S3-compatible; sin egress fees |
| CDN | Cloudflare | Cache de assets estáticos |
| Email | SendGrid | Template transaccional |

## 10. Variables de Entorno requeridas en producción

Ver `backend/.env.example` para el listado completo con descripción de cada variable.

Las variables críticas que DEBEN cambiarse del ejemplo:
- `APP_KEY` — php artisan key:generate
- `JWT_SECRET` — php artisan jwt:secret
- `DB_PASSWORD`
- Credenciales de la pasarela de pago activa
- Credenciales AWS/Azure para reconocimiento facial
- `MAIL_PASSWORD` (SendGrid API Key)
