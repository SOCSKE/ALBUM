#!/usr/bin/env bash
# ============================================================
# setup.sh — Configuración inicial del entorno de desarrollo
# Uso: bash scripts/setup.sh
# ============================================================
set -e

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${BLUE}╔════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║  Álbum Digital FIFA World Cup 2026 Setup  ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════╝${NC}"
echo ""

# ──────────────────────────────────────────
# 1. Verificar dependencias
# ──────────────────────────────────────────
echo -e "${YELLOW}[1/7] Verificando dependencias...${NC}"

command -v docker   >/dev/null 2>&1 || { echo "ERROR: Docker no encontrado"; exit 1; }
command -v docker-compose >/dev/null 2>&1 || { echo "ERROR: Docker Compose no encontrado"; exit 1; }
command -v php      >/dev/null 2>&1 || { echo "WARNING: PHP no encontrado (se usará Docker)"; }
command -v node     >/dev/null 2>&1 || { echo "WARNING: Node.js no encontrado (se usará Docker)"; }
command -v composer >/dev/null 2>&1 || { echo "WARNING: Composer no encontrado (se usará Docker)"; }

echo -e "${GREEN}✓ Dependencias verificadas${NC}"

# ──────────────────────────────────────────
# 2. Variables de entorno Backend
# ──────────────────────────────────────────
echo -e "${YELLOW}[2/7] Configurando entorno Backend...${NC}"

if [ ! -f backend/.env ]; then
  cp backend/.env.example backend/.env
  echo -e "${GREEN}✓ backend/.env creado${NC}"
else
  echo -e "  backend/.env ya existe, omitiendo"
fi

# ──────────────────────────────────────────
# 3. Variables de entorno Frontend
# ──────────────────────────────────────────
echo -e "${YELLOW}[3/7] Configurando entorno Frontend...${NC}"

if [ ! -f frontend/.env.local ]; then
  cat > frontend/.env.local << 'EOF'
NEXT_PUBLIC_API_URL=http://localhost:8000/api
NEXT_PUBLIC_APP_URL=http://localhost:3000
NEXT_PUBLIC_APP_NAME="Album Digital FIFA 2026"
EOF
  echo -e "${GREEN}✓ frontend/.env.local creado${NC}"
else
  echo -e "  frontend/.env.local ya existe, omitiendo"
fi

# ──────────────────────────────────────────
# 4. Levantar servicios Docker
# ──────────────────────────────────────────
echo -e "${YELLOW}[4/7] Iniciando servicios Docker...${NC}"

cd docker
docker-compose up -d mysql redis mailpit
echo -e "${GREEN}✓ MySQL, Redis y Mailpit iniciados${NC}"

echo "  Esperando que MySQL esté listo..."
sleep 8

cd ..

# ──────────────────────────────────────────
# 5. Backend: dependencias + migraciones
# ──────────────────────────────────────────
echo -e "${YELLOW}[5/7] Configurando Backend Laravel...${NC}"

if command -v php >/dev/null 2>&1 && command -v composer >/dev/null 2>&1; then
  cd backend
  composer install --no-interaction
  php artisan key:generate
  php artisan jwt:secret
  php artisan migrate --seed
  echo -e "${GREEN}✓ Backend configurado${NC}"
  cd ..
else
  echo "  Usando Docker para backend..."
  docker-compose -f docker/docker-compose.yml exec backend composer install --no-interaction
  docker-compose -f docker/docker-compose.yml exec backend php artisan key:generate
  docker-compose -f docker/docker-compose.yml exec backend php artisan jwt:secret
  docker-compose -f docker/docker-compose.yml exec backend php artisan migrate --seed
fi

# ──────────────────────────────────────────
# 6. Frontend: dependencias
# ──────────────────────────────────────────
echo -e "${YELLOW}[6/7] Instalando dependencias Frontend...${NC}"

if command -v node >/dev/null 2>&1; then
  cd frontend
  npm install
  echo -e "${GREEN}✓ Frontend configurado${NC}"
  cd ..
else
  echo "  Node.js no encontrado, usar Docker para el frontend"
fi

# ──────────────────────────────────────────
# 7. Levantar todo
# ──────────────────────────────────────────
echo -e "${YELLOW}[7/7] Iniciando plataforma completa...${NC}"

docker-compose -f docker/docker-compose.yml up -d

echo ""
echo -e "${GREEN}╔════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║         ¡Configuración completa!           ║${NC}"
echo -e "${GREEN}╚════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  🎮 Frontend:   ${BLUE}http://localhost:3000${NC}"
echo -e "  🔧 Backend:    ${BLUE}http://localhost:8000/api${NC}"
echo -e "  📖 API Docs:   ${BLUE}http://localhost:8000/api/documentation${NC}"
echo -e "  📧 Mailpit:    ${BLUE}http://localhost:8025${NC}"
echo -e "  🗄️  MySQL:      localhost:3306  (usuario: album_user)"
echo ""
echo -e "  Usuario superadmin: admin@albumdigital2026.com"
echo -e "  Contraseña:         Admin2026!"
echo ""
