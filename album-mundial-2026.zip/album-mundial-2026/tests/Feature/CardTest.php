<?php

namespace Tests\Feature;

use App\Models\AlbumCard;
use App\Models\Player;
use App\Models\Tenant;
use App\Services\CardService;
use App\Services\FaceMatchService;
use App\Services\PhotoFraudService;
use App\Services\StorageService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Mockery;
use Tests\TestCase;

class CardCaptureTest extends TestCase
{
    use RefreshDatabase;

    private CardService $cardService;
    private Tenant      $tenant;
    private Player      $owner;
    private Player      $subject;

    protected function setUp(): void
    {
        parent::setUp();

        // Mocks
        $faceMatch  = Mockery::mock(FaceMatchService::class);
        $fraudCheck = Mockery::mock(PhotoFraudService::class);
        $storage    = Mockery::mock(StorageService::class);

        $faceMatch->shouldReceive('compare')->andReturn(92.5)->byDefault();
        $fraudCheck->shouldReceive('analyze')->andReturn((object)[
            'isBlocked' => false,
            'flags'     => [],
            'type'      => null,
            'photoHash' => null,
        ])->byDefault();
        $storage->shouldReceive('uploadPhoto')->andReturn('events/test/photo.jpg')->byDefault();
        $storage->shouldReceive('url')->andReturn('https://r2.example.com/photo.jpg')->byDefault();

        $this->cardService = new CardService($faceMatch, $fraudCheck, $storage);

        // Crear datos de prueba
        $this->tenant  = Tenant::factory()->active()->create();
        $this->owner   = Player::factory()->for($this->tenant)->create();
        $this->subject = Player::factory()->for($this->tenant)->create();
    }

    /** @test */
    public function it_creates_approved_card_when_face_score_exceeds_threshold(): void
    {
        $photo = UploadedFile::fake()->image('photo.jpg');

        $card = $this->cardService->capture(
            owner:     $this->owner,
            subjectId: $this->subject->id,
            photo:     $photo,
            ipAddress: '192.168.1.1',
        );

        $this->assertInstanceOf(AlbumCard::class, $card);
        $this->assertEquals('approved', $card->face_match_status);
        $this->assertEquals(92.5, $card->face_match_score);
        $this->assertDatabaseHas('album_cards', [
            'owner_id'          => $this->owner->id,
            'subject_id'        => $this->subject->id,
            'face_match_status' => 'approved',
        ]);
    }

    /** @test */
    public function it_sends_to_review_when_face_score_is_below_threshold(): void
    {
        $faceMatch = Mockery::mock(FaceMatchService::class);
        $faceMatch->shouldReceive('compare')->andReturn(65.0);

        $fraudCheck = Mockery::mock(PhotoFraudService::class);
        $fraudCheck->shouldReceive('analyze')->andReturn((object)[
            'isBlocked' => false, 'flags' => [], 'type' => null, 'photoHash' => null,
        ]);

        $storage = Mockery::mock(StorageService::class);
        $storage->shouldReceive('uploadPhoto')->andReturn('path/photo.jpg');
        $storage->shouldReceive('url')->andReturn('https://r2.example.com/photo.jpg');

        $service = new CardService($faceMatch, $fraudCheck, $storage);
        $photo   = UploadedFile::fake()->image('photo.jpg');

        $card = $service->capture($this->owner, $this->subject->id, $photo, '10.0.0.1');

        $this->assertEquals('pending_review', $card->face_match_status);
    }

    /** @test */
    public function it_throws_exception_when_card_already_exists(): void
    {
        $this->expectException(\DomainException::class);
        $this->expectExceptionMessage('Ya tienes este cromo en tu álbum.');

        // Crear cromo existente
        AlbumCard::factory()->create([
            'tenant_id'         => $this->tenant->id,
            'owner_id'          => $this->owner->id,
            'subject_id'        => $this->subject->id,
            'face_match_status' => 'approved',
        ]);

        $photo = UploadedFile::fake()->image('photo2.jpg');
        $this->cardService->capture($this->owner, $this->subject->id, $photo, '10.0.0.1');
    }

    /** @test */
    public function it_blocks_fraudulent_photos(): void
    {
        $this->expectException(\DomainException::class);
        $this->expectExceptionMessage('Foto rechazada: duplicate');

        $fraudCheck = Mockery::mock(PhotoFraudService::class);
        $fraudCheck->shouldReceive('analyze')->andReturn((object)[
            'isBlocked' => true,
            'reason'    => 'duplicate',
            'type'      => 'duplicate',
            'flags'     => ['duplicate_hash'],
            'photoHash' => 'abc123',
        ]);

        $faceMatch = Mockery::mock(FaceMatchService::class);
        $storage   = Mockery::mock(StorageService::class);

        $service = new CardService($faceMatch, $fraudCheck, $storage);
        $photo   = UploadedFile::fake()->image('dup.jpg');
        $service->capture($this->owner, $this->subject->id, $photo, '10.0.0.1');
    }

    /** @test */
    public function it_updates_player_album_progress_after_card_capture(): void
    {
        $photo = UploadedFile::fake()->image('photo.jpg');
        $this->cardService->capture($this->owner, $this->subject->id, $photo, '10.0.0.1');

        // El trigger MySQL debería haber actualizado el progreso
        $this->owner->refresh();
        $this->assertGreaterThan(0, $this->owner->album_progress);
    }
}

// ──────────────────────────────────────────────────────────────
// TESTS DE PRECIOS
// ──────────────────────────────────────────────────────────────
class PriceCalculationTest extends TestCase
{
    /** @test */
    public function it_calculates_price_correctly_for_25_players(): void
    {
        $pricing = \App\Services\Payment\PaymentService::calculatePrice(25);

        $this->assertEquals(1, $pricing['blocks']);
        $this->assertEquals(5.00, $pricing['total_usd']);
    }

    /** @test */
    public function it_calculates_price_for_50_players(): void
    {
        $pricing = \App\Services\Payment\PaymentService::calculatePrice(50);

        $this->assertEquals(2, $pricing['blocks']);
        $this->assertEquals(10.00, $pricing['total_usd']);
    }

    /** @test */
    public function it_calculates_price_for_500_players(): void
    {
        $pricing = \App\Services\Payment\PaymentService::calculatePrice(500);

        $this->assertEquals(20, $pricing['blocks']);
        $this->assertEquals(100.00, $pricing['total_usd']);
    }

    /**
     * @test
     * @dataProvider priceDataProvider
     */
    public function it_calculates_correct_prices(int $players, float $expected): void
    {
        $pricing = \App\Services\Payment\PaymentService::calculatePrice($players);
        $this->assertEquals($expected, $pricing['total_usd']);
    }

    public static function priceDataProvider(): array
    {
        return [
            'block 1'  => [1,   5.00],
            'block 1 full' => [25, 5.00],
            'block 2'  => [26,  10.00],
            'block 4'  => [100, 20.00],
            'block 20' => [500, 100.00],
        ];
    }
}

// ──────────────────────────────────────────────────────────────
// TESTS DE MULTI-TENANCY
// ──────────────────────────────────────────────────────────────
class MultiTenancyTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function player_cannot_access_cards_from_other_tenant(): void
    {
        $tenant1 = Tenant::factory()->active()->create(['slug' => 'EVENT1']);
        $tenant2 = Tenant::factory()->active()->create(['slug' => 'EVENT2']);

        $player1 = Player::factory()->for($tenant1)->create();
        $player2 = Player::factory()->for($tenant2)->create();

        // Autenticar como player1 en tenant1
        $token = auth('players')->login($player1);

        $response = $this->withToken($token)
            ->getJson("/api/game/EVENT1/players/{$player2->id}/card");

        $response->assertStatus(404);
    }

    /** @test */
    public function event_link_is_unique_per_tenant(): void
    {
        $tenant1 = Tenant::factory()->create(['slug' => 'UNIQUE1']);
        $tenant2 = Tenant::factory()->create(['slug' => 'UNIQUE2']);

        $this->assertNotEquals($tenant1->slug, $tenant2->slug);
    }
}
